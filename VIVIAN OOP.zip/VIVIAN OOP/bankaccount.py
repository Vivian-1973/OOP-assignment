class BankAccount:
    # Class variable to represent the bank's interest rate
    interest_rate = 0.05

    def __init__(self, account_holder):
        # Instance variables for account holder's name and balance
        self.account_holder = account_holder
        self.balance = 0.0  # Initial balance is zero

    def deposit(self, amount):
        if amount > 0:
            self.balance += amount
            print(f"Deposited shs{amount}. New balance: shs{self.balance}")
        else:
            print("Deposit amount must be greater than zero.")

    def withdraw(self, amount):
        if amount > 0 and self.balance >= amount:
            self.balance -= amount
            print(f"Withdrew shs{amount}. New balance: shs{self.balance}")
        elif amount > 0:
            print("Insufficient funds!")
        else:
            print("Withdrawal amount must be greater than zero.")

    def apply_interest(self):
        interest_amount = self.balance * BankAccount.interest_rate
        self.balance += interest_amount
        print(f"Interest applied: shs{interest_amount}. New balance: shs{self.balance}")

    def display_account_info(self):
        print(f"Account Holder: {self.account_holder}, Balance: shs{self.balance:.2f}")


# Create two instances of BankAccount with different account holders
account1 = BankAccount("Alice")
account2 = BankAccount("Bob")

# Perform a few deposits and withdrawals
account1.deposit(1000)
account1.withdraw(300)

account2.deposit(500)
account2.withdraw(100)

# Apply interest
account1.apply_interest()
account2.apply_interest()

# Display account information for each account
account1.display_account_info()
account2.display_account_info()
