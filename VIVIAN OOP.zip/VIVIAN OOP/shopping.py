class Product:
    def __init__(self, product_name, price, quantity_in_stock):
        # Instance variables for product details
        self.product_name = product_name
        self.price = price
        self.quantity_in_stock = quantity_in_stock

    def display_product_info(self):
        """Displays the product details."""
        print(f"Product: {self.product_name}, Price: ${self.price:.2f}, Quantity in Stock: {self.quantity_in_stock}")


class ShoppingCart:
    # Class variable to track total number of shopping carts created
    total_carts = 0

    def __init__(self):
        ShoppingCart.total_carts += 1
        self.items = []  # List of tuples, each containing a product and its quantity

    def add_to_cart(self, product, quantity):
        if product.quantity_in_stock >= quantity:
            # Reduce the product's stock by the quantity added to the cart
            product.quantity_in_stock -= quantity
            # Add the product and quantity to the shopping cart
            self.items.append((product, quantity))
            print(f"Added {quantity} of {product.product_name} to the cart.")
        else:
            print(f"Sorry, insufficient stock for {product.product_name}. Only {product.quantity_in_stock} left.")

    def remove_from_cart(self, product):
        for i, (cart_product, quantity) in enumerate(self.items):
            if cart_product == product:
                # Restore the product quantity to stock
                product.quantity_in_stock += quantity
                # Remove the product from the cart
                self.items.pop(i)
                print(f"Removed {product.product_name} from the cart.")
                return
        print(f"{product.product_name} not found in the cart.")

    def display_cart(self):
        if not self.items:
            print("Your cart is empty.")
        else:
            print("\nItems in your cart:")
            for cart_product, quantity in self.items:
                print(f"Product: {cart_product.product_name}, Quantity: {quantity}, Total Price: ${cart_product.price * quantity:.2f}")
    
    def calculate_total(self):
        total = sum(cart_product.price * quantity for cart_product, quantity in self.items)
        return total


# Create three Product objects with varying prices and quantities
product1 = Product("Laptop", 1000.00, 5)
product2 = Product("Smartphone", 500.00, 10)
product3 = Product("Headphones", 50.00, 20)

# Create two separate ShoppingCart instances
cart1 = ShoppingCart()
cart2 = ShoppingCart()

# Perform a series of operations for cart1
cart1.add_to_cart(product1, 2)  # Adding 2 Laptops to cart1
cart1.add_to_cart(product2, 3)  # Adding 3 Smartphones to cart1
cart1.remove_from_cart(product1)  # Removing 2 Laptops from cart1

# Perform a series of operations for cart2
cart2.add_to_cart(product2, 1)  # Adding 1 Smartphone to cart2
cart2.add_to_cart(product3, 5)  # Adding 5 Headphones to cart2

# Display the contents of each cart
print("\nCart 1 Contents:")
cart1.display_cart()
print(f"Total Price for Cart 1: ${cart1.calculate_total():.2f}")

print("\nCart 2 Contents:")
cart2.display_cart()
print(f"Total Price for Cart 2: ${cart2.calculate_total():.2f}")

